$(function(){
    $('.close').click(function(){
        $('#msg').hide('slow')
    })
})