

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-8 offset-2">
          
<form action="<?php echo e(route('internaute.update',$internaute->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <fieldset>
<legend>Modiffication : <?php echo e($internaute->name); ?> <?php echo e($internaute->firstname); ?></legend>

        <!-- name -->
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Nom</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name="name" value="<?php echo e($internaute->name); ?>">
                <?php if($errors->has('name')): ?>
                    <p class="text-danger"><?php echo e($errors->first('name')); ?></p>
                <?php endif; ?>
            </div>
        </div>

        <!-- firstname -->
        <div class="form-group row">
            <label class="form-label col-md-2">Prénoms</label>
            <div class="col-md-10">
                <input type="text" name="firstname" class="form-control" value="<?php echo e($internaute->firstname); ?>">
                <?php if($errors->has('firstname')): ?>
                    <p class="text-danger"><?php echo e($errors->first('firstname')); ?></p>
                <?php endif; ?>
            </div>
        </div>

        <!-- email -->
        <div class="form-group row">
            <label class="col-md-2 col-form-label">Email</label>
            <div class="col-md-10">
                <input type="email" name="email" class="form-control" value="<?php echo e($internaute->email); ?>">
                <?php if($errors->has('email')): ?>
                    <P  class="text-danger"><?php echo e($errors->first('email')); ?></P>
                <?php endif; ?>
            </div>
        </div>

        <!-- age -->
        <div class="form-group row">
            <label class="form-label col-md-2">Âge</label>
            <div class="col-md-2">
                <input type="number" class="form-control" min="0" name="age" value="<?php echo e($internaute->age); ?>">
                <?php if($errors->has('age')): ?>
                    <P class="text-danger"><?php echo e($errors->first('age')); ?></P>
                <?php endif; ?>
            </div>
        </div>

        <button type="submit" class="btn btn-block btn-danger">Submit</button>

    </fieldset>
</form>



        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravels\crud\crud\resources\views/edit.blade.php ENDPATH**/ ?>