<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="jumbotron">
                <h1 class="display-3">
                    <font style="vertical-align: inherit;">
                        <font style="vertical-align: center;"> Internaute Viewver </font>
                    </font>
                </ h1>
                <p class="lead">
                    <font style="vertical-align: inherit;">
                        <font style="vertical-align: inherit;"> Est une application Permetant de Faire des 
                            Crud(create read update delete) d'informations des internautes
                        </font>
                    </font>
                </p>
                <hr class="my-4">
                <p>
                    <font style="vertical-align: inherit;">
                        <font style="vertical-align: inherit;"> Vous pouvez utiliser les options ci-dessous pour visualiser,
                             insérer, modifier ou supprimer des ressources.
                        </font>
                    </font>
                </p>
                <p class="lead">
                    <a class="btn btn-success btn-lg" href="#" role="button">
                        <font style="vertical-align: inherit;">
                            <font style="vertical-align: inherit;">> visualiser </font>
                        </font>
                    </a>
                    <a class="btn btn-warning btn-lg" href="#" role="button">
                        <font style="vertical-align: inherit;">
                            <font style="vertical-align: inherit;">> Ajouter </font>
                        </font>
                    </a>
                </p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravels\crud\crud\resources\views/welcome.blade.php ENDPATH**/ ?>