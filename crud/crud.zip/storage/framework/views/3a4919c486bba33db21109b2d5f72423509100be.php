

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-5 offset-1">
            <h1 class="text-primary">Liste des Internautes</h1>
        </div>
        <div class="col-2 offset-2">
            <a href="<?php echo e(route('internaute.create')); ?>" class="btn btn-primary">Creer Nouveau</a>
        </div>
    </div>

    <div class="row">
        <div class="col-10 offset-1">
          

        <table class="table table-hover ">
            <thead>
                <tr>
                <th scope="col">#</th>
                <th scope="col">Nom</th>
                <th scope="col">Prénoms</th>
                <th scope="col">Âge</th>
                <th scope="col">E-Mail</th>
                <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
               <?php $__currentLoopData = $internautes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $internaute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <th><?php echo e($internaute->id); ?></th>
                <td><?php echo e($internaute->name); ?></td>
                <td><?php echo e($internaute->firstname); ?></td>
                <td><?php echo e($internaute->age); ?></td>
                <td><?php echo e($internaute->email); ?></td>
                <td>
                    <form method="POST" action="<?php echo e(route('internaute.destroy',$internaute->id)); ?>" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <input class="btn btn-xs btn-danger" type="submit" value="🗑️ Supprimer">
                    </form>
                    <a class="btn btn-xs btn-info" href="<?php echo e(route('internaute.edit',$internaute->id)); ?>">🖊️ Editer</a>
                </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table> 


        </div>
    </div>
    <div class="row">
        <div class="col-3">
            <?php echo e($internautes->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravels\crud\crud\resources\views/liste.blade.php ENDPATH**/ ?>